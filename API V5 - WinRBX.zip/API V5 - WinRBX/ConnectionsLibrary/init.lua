local ConnectionLibrary = {}



ConnectionLibrary.Connections = {}



function ConnectionLibrary.addConnection(key, connection)
    return require(script.addConnection)(ConnectionLibrary.Connections, key, connection)
end


function ConnectionLibrary.removeConnection(key)
    return require(script.removeConnection)(ConnectionLibrary.Connections, key)
end


function ConnectionLibrary.findFirstConnection(key)
    return require(script.findFirstConnection)(ConnectionLibrary.Connections, key)
end


function ConnectionLibrary.overrideConnection(key, newConnection)
    return require(script.overrideConnection)(ConnectionLibrary.Connections, key, newConnection)
end

function ConnectionLibrary.disconnectConnection(key)
    return require(script.disconnectConnection)(ConnectionLibrary.Connections, key)
end




ConnectionLibrary.add = ConnectionLibrary.addConnection
ConnectionLibrary.remove = ConnectionLibrary.removeConnection
ConnectionLibrary.find = ConnectionLibrary.findFirstConnection
ConnectionLibrary.override = ConnectionLibrary.overrideConnection
ConnectionLibrary.disconnect = ConnectionLibrary.disconnectConnection



return ConnectionLibrary