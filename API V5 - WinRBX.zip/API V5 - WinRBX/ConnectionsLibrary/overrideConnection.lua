local remove = require(script.Parent.removeConnection)
local find = require(script.Parent.findFirstConnection)
local add = require(script.Parent.addConnection)


return function(tbl, key, newConnection)
    if find(tbl, key) ~= nil then
        remove(tbl, key)
        add(tbl, key, newConnection)
    else
        add(tbl, key, newConnection)
    end
end