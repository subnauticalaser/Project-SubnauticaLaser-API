return function(tbl, key)
    return tbl[key]
end