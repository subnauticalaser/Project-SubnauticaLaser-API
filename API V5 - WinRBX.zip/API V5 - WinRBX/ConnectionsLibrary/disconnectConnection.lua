local find = require(script.Parent.findFirstConnection)

return function(tbl, key)
    if find(tbl, key) ~= nil then
        tbl[key]:Disconnect()
    end
end