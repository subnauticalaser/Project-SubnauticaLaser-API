return function(tbl, key, connection)
    if tbl[key] then
        warn('key: ' .. tostring(key) .. ' is already in use, please use `ConnectionLibrary.overrideConnection(key, newConnection)`')
        return
    end

    tbl[key] = connection
end