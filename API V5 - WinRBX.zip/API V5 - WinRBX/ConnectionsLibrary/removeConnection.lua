local disconnect = require(script.Parent.disconnectConnection)
local find = require(script.Parent.findFirstConnection)

return function(tbl, key)
	if find(tbl, key) ~= nil then
        disconnect(tbl, key)
        tbl[key] = nil
	else
		warn('key: ' .. tostring(key) .. ' is not defined.')
	end
end